module.exports = {
    token: "ODc2OTY4NDYzNjc4MTc3Mjkw.YRryhw.xKMMmnhvMtM3CydhssTMT10v37c",
    prefix: "!",
    prefix2: "/"
}