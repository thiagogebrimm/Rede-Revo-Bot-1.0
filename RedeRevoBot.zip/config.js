module.exports = {
    token: "ODQzNjU1ODEzMjIxNTgwODAw.YKHBtA.HbFh4RNkTgFT9dUBxen6t3Y7Ixo",
    prefix: "!",
    prefix2: "/"
}